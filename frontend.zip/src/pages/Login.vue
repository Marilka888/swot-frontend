<template>
  <my-login />
</template>
<script>
import MyLogin from '../components/MyLogin'

export default {
  name: 'LoginPage',
  components: {
    MyLogin
  }
}
</script>
