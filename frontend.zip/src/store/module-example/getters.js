export function someGetter (/* state */) {
}
